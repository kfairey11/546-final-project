package com.example.homework05

data class MyData(val imageNumber: Int, val text1: String, val text2: String)